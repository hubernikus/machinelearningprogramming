%% Mountain Car Example With Sarsa No function approximation
clear all;
%%
addpath(genpath('./methods/reinforcement_learning/MoutainCar'));