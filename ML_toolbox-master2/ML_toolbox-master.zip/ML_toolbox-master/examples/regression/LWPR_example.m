%% Example of using LWPR
clear all;
%%

test_lwpr_1D();