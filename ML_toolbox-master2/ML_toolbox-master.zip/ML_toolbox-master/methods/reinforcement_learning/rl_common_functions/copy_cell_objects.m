function [ output_args ] = copy_cell_objects( objects )
%COPY_CELL_OBJECTS Summary of this function goes here
%   Detailed explanation goes here

iscell(objects


end

