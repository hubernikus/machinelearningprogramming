Mountain Car Problem with SARSA 
Programmed in Matlab 
by:
 Jose Antonio Martin H. <jamartinh@fdi.ucm.es>

See Sutton & Barto book: Reinforcement Learning p.214




To run the demo use:



>> Demo <enter>



or



>> MountainCarDemo(number_of_episodes) <enter>  


i.e. >> MountainCarDemo(200) <enter> 