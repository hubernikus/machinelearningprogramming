Mountain Car Problem with the award wining kNN-TD(lambda) 
This algorithm won in the Reinforcement Learning competition 2008 and 2009.
by:
Jose Antonio Martin H. <jamartinh@fdi.ucm.es>

To run the demo use:


>> Demo <enter>



or



>> MountainCarDemo(number_of_episodes) <enter>  ( e.g. >> MountainCarDemo(200)<enter>  )
