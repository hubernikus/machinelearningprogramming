function ml_plot_hyperplane(W,b)
%ML_PLOT_HYPERPLANE Plots a hyperplane
%
%   Plots a hyperplane (2D & 3D), function defined by:
%   f = [W ; b]^T x
%
%


end

